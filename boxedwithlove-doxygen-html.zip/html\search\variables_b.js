var searchData=
[
  ['order_5fid_0',['order_id',['../classmodels_1_1_order_item.html#af40afdad7e6b5fb0fe1e57217d61cc40',1,'models::OrderItem']]]
];
