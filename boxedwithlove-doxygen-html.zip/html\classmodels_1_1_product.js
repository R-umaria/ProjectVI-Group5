var classmodels_1_1_product =
[
    [ "__tablename__", "classmodels_1_1_product.html#a74fa30517affc6516aa571bca8b255be", null ],
    [ "category", "classmodels_1_1_product.html#a897db139b6d292723ef307d90897ea25", null ],
    [ "category_id", "classmodels_1_1_product.html#a8b2b0c50363fe96c76174414fa23dfd1", null ],
    [ "created_at", "classmodels_1_1_product.html#a84cf7f84da7a2273768da096d2a1d795", null ],
    [ "description", "classmodels_1_1_product.html#a9874987fccab2bf056f59505638f6d3e", null ],
    [ "id", "classmodels_1_1_product.html#a8d910faf95428b84971373690a3513f7", null ],
    [ "image_url", "classmodels_1_1_product.html#acf333b52397e1bce75ba14b20a266ab8", null ],
    [ "is_available", "classmodels_1_1_product.html#a031c2f2d3e60098350c47597a310dd52", null ],
    [ "name", "classmodels_1_1_product.html#adc3403af25fb7742059011bbc6be4176", null ],
    [ "price_cents", "classmodels_1_1_product.html#abdaac8ea6b6108eb1ec13562a2a6ed31", null ],
    [ "reviews", "classmodels_1_1_product.html#a7cd9aa7a5b6c18d8f21296e92939245d", null ],
    [ "sku", "classmodels_1_1_product.html#a8a003a41e661a2f4b549bc0c551466e0", null ],
    [ "stock", "classmodels_1_1_product.html#a82ebfb7e2c3a29ffece50e1938ebdb32", null ]
];