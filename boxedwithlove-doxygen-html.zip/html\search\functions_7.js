var searchData=
[
  ['list_5forders_0',['list_orders',['../namespaceroutes_1_1orders.html#aa55e88c12b0d700d71c6b5f0b5d93cad',1,'routes::orders']]],
  ['list_5fpayment_5fmethods_1',['list_payment_methods',['../namespaceroutes_1_1payment__methods.html#a05781f54459c6d9cd87b94a0fde850d9',1,'routes::payment_methods']]],
  ['list_5fproducts_2',['list_products',['../namespaceroutes_1_1catalog.html#a2117586627dd83b8724235b243b1ccea',1,'routes::catalog']]],
  ['login_3',['login',['../namespaceroutes_1_1auth.html#a5634e48b8913b959701258b269357eab',1,'routes::auth']]],
  ['logout_4',['logout',['../namespaceroutes_1_1auth.html#abcf624a86a19d8b2dcd3f6ddec10779d',1,'routes::auth']]]
];
