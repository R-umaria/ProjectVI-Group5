var searchData=
[
  ['set_5fsession_5fcart_0',['set_session_cart',['../namespaceroutes_1_1cart.html#aa1400ca9b6dbbf477bd7cd6b1bb010cf',1,'routes::cart']]]
];
