var searchData=
[
  ['validate_5fpayload_0',['validate_payload',['../namespaceroutes_1_1payment__methods.html#aa0d6ba401624b94fd16f2901bbcb708a',1,'routes::payment_methods']]]
];
