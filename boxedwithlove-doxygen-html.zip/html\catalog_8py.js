var catalog_8py =
[
    [ "routes.catalog.add_review", "namespaceroutes_1_1catalog.html#acdfe3ca0508fa479d2ff533630d67000", null ],
    [ "routes.catalog.list_products", "namespaceroutes_1_1catalog.html#a2117586627dd83b8724235b243b1ccea", null ],
    [ "routes.catalog.product_detail", "namespaceroutes_1_1catalog.html#a59b3fa152eba208a533b4d1b13ec2fdc", null ],
    [ "routes.catalog.bp", "namespaceroutes_1_1catalog.html#adff7be7f43944f8ee0e229f19d406e49", null ]
];