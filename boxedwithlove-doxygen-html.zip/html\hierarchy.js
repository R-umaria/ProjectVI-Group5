var hierarchy =
[
    [ "config.Config", "classconfig_1_1_config.html", null ],
    [ "db.Model", null, [
      [ "models.Address", "classmodels_1_1_address.html", null ],
      [ "models.CartItem", "classmodels_1_1_cart_item.html", null ],
      [ "models.Category", "classmodels_1_1_category.html", null ],
      [ "models.Order", "classmodels_1_1_order.html", null ],
      [ "models.OrderItem", "classmodels_1_1_order_item.html", null ],
      [ "models.PaymentMethod", "classmodels_1_1_payment_method.html", null ],
      [ "models.Product", "classmodels_1_1_product.html", null ],
      [ "models.Review", "classmodels_1_1_review.html", null ],
      [ "models.User", "classmodels_1_1_user.html", null ]
    ] ]
];