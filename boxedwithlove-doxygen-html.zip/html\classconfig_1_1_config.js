var classconfig_1_1_config =
[
    [ "DEFAULT_LIMIT", "classconfig_1_1_config.html#a9907409732c1c5dacf71634b2af5ce15", null ],
    [ "MAX_LIMIT", "classconfig_1_1_config.html#a5d1af9583aecf7e91c9832df57abd2d8", null ],
    [ "SECRET_KEY", "classconfig_1_1_config.html#afa91486023a7d328ba84e8d653249bf0", null ],
    [ "SQLALCHEMY_DATABASE_URI", "classconfig_1_1_config.html#af66c39ecc8c74ba285f7202ef142a3b4", null ],
    [ "SQLALCHEMY_TRACK_MODIFICATIONS", "classconfig_1_1_config.html#aaefa3e10f50e9f49531985aeb61f8c98", null ]
];