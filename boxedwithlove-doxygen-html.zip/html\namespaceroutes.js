var namespaceroutes =
[
    [ "auth", "namespaceroutes_1_1auth.html", [
      [ "get_me", "namespaceroutes_1_1auth.html#a941ceeac034b6fc791b1b65cd0b9c29c", null ],
      [ "get_password_errors", "namespaceroutes_1_1auth.html#ae72d63c7f169b0e6974046e7a6397bd5", null ],
      [ "login", "namespaceroutes_1_1auth.html#a5634e48b8913b959701258b269357eab", null ],
      [ "logout", "namespaceroutes_1_1auth.html#abcf624a86a19d8b2dcd3f6ddec10779d", null ],
      [ "register", "namespaceroutes_1_1auth.html#a4a26c96d5d787a01771914c46c28db00", null ],
      [ "bp", "namespaceroutes_1_1auth.html#ab593a571145431d044fca7c3625831ba", null ],
      [ "EMAIL_REGEX", "namespaceroutes_1_1auth.html#aeb88a12da324443158529d05ba1bff95", null ]
    ] ],
    [ "cart", "namespaceroutes_1_1cart.html", [
      [ "add_to_cart", "namespaceroutes_1_1cart.html#a8c7727a491f55e8f2a56f1b917c111b6", null ],
      [ "delete_cart_item", "namespaceroutes_1_1cart.html#aa06a42cde515b508eb449a3222054bc4", null ],
      [ "get_cart", "namespaceroutes_1_1cart.html#a15d0c15f33a771d62c250103f832d682", null ],
      [ "get_session_cart", "namespaceroutes_1_1cart.html#ad1cfd8ccddd8e1eed56844e0d8f66322", null ],
      [ "partial_update_cart_item", "namespaceroutes_1_1cart.html#a146b7142cd43cdb30bde204ae7e45db2", null ],
      [ "set_session_cart", "namespaceroutes_1_1cart.html#aa1400ca9b6dbbf477bd7cd6b1bb010cf", null ],
      [ "update_cart_item", "namespaceroutes_1_1cart.html#a9eeac49273c3a0d3d7f04702d013a565", null ],
      [ "bp", "namespaceroutes_1_1cart.html#ad1fc274e39627600fb1fe76233248410", null ]
    ] ],
    [ "catalog", "namespaceroutes_1_1catalog.html", [
      [ "add_review", "namespaceroutes_1_1catalog.html#acdfe3ca0508fa479d2ff533630d67000", null ],
      [ "list_products", "namespaceroutes_1_1catalog.html#a2117586627dd83b8724235b243b1ccea", null ],
      [ "product_detail", "namespaceroutes_1_1catalog.html#a59b3fa152eba208a533b4d1b13ec2fdc", null ],
      [ "bp", "namespaceroutes_1_1catalog.html#adff7be7f43944f8ee0e229f19d406e49", null ]
    ] ],
    [ "options", "namespaceroutes_1_1options.html", [
      [ "options_route", "namespaceroutes_1_1options.html#a83109a171ef4f724f009da3b4aa05f2e", null ],
      [ "bp", "namespaceroutes_1_1options.html#a1f0ec048e9fe9e4676f7b6ac090f9ad4", null ]
    ] ],
    [ "orders", "namespaceroutes_1_1orders.html", [
      [ "create_order", "namespaceroutes_1_1orders.html#adf654edd7d8cecf8a10180c33ffe104a", null ],
      [ "delete_order", "namespaceroutes_1_1orders.html#a486a68249092b0daee16e948d4616cc9", null ],
      [ "ensure_payment_method", "namespaceroutes_1_1orders.html#a28857a0467b2ed333755763bd4c906e9", null ],
      [ "get_order", "namespaceroutes_1_1orders.html#af02bf1e87662e04caa321b833c0c912c", null ],
      [ "list_orders", "namespaceroutes_1_1orders.html#aa55e88c12b0d700d71c6b5f0b5d93cad", null ],
      [ "order_to_dict", "namespaceroutes_1_1orders.html#ab6579d3146331f02bb81fcd9b6f08a56", null ],
      [ "orders_options_collection", "namespaceroutes_1_1orders.html#ae453efa4018a45ff4697fa8fd9ea45cc", null ],
      [ "orders_options_item", "namespaceroutes_1_1orders.html#a0192a3bdcc717e86a52f5fa1da89bd6f", null ],
      [ "patch_order", "namespaceroutes_1_1orders.html#ac2dd20ff16ff4ff7a2869aed4b9176d0", null ],
      [ "require_user_id", "namespaceroutes_1_1orders.html#a28b4b9a0d2e698d1a6583a03aefd09da", null ],
      [ "bp", "namespaceroutes_1_1orders.html#a5460084f970cc7354c952867557be48d", null ],
      [ "TAX_RATE", "namespaceroutes_1_1orders.html#a8a9e52b76fc29408f7819a2e82638b83", null ]
    ] ],
    [ "payment_methods", "namespaceroutes_1_1payment__methods.html", [
      [ "apply_default_rule", "namespaceroutes_1_1payment__methods.html#ac7148d4eb400cf50105277c4cd4ce8fb", null ],
      [ "create_payment_method", "namespaceroutes_1_1payment__methods.html#ada95b63c06d686df5aa8376d29259f3f", null ],
      [ "delete_payment_method", "namespaceroutes_1_1payment__methods.html#a8e16b9d588d4f6a7a7ee8f7f11374bd5", null ],
      [ "find_duplicate", "namespaceroutes_1_1payment__methods.html#a3a1aa75b493afad68932ffa5b3d9000d", null ],
      [ "list_payment_methods", "namespaceroutes_1_1payment__methods.html#a05781f54459c6d9cd87b94a0fde850d9", null ],
      [ "normalize_last4", "namespaceroutes_1_1payment__methods.html#a17c78fdd4ce77c985462f04a8b5a6591", null ],
      [ "payment_methods_options_collection", "namespaceroutes_1_1payment__methods.html#a49d023f1094841c5fe62e0138e61f2c6", null ],
      [ "payment_methods_options_item", "namespaceroutes_1_1payment__methods.html#a7f01c53b567ff4813b6c49097f6c2c64", null ],
      [ "replace_payment_method", "namespaceroutes_1_1payment__methods.html#aafbbb9b6519fa7911981082473be8b49", null ],
      [ "require_user_id", "namespaceroutes_1_1payment__methods.html#a4ccd9a1ba520fe87c47ddb33bd2cc91e", null ],
      [ "to_dict", "namespaceroutes_1_1payment__methods.html#a21cf32bc69aa8756cfd16548cd911833", null ],
      [ "update_payment_method", "namespaceroutes_1_1payment__methods.html#a74df6f97682f322527c309abe8ecc74e", null ],
      [ "validate_payload", "namespaceroutes_1_1payment__methods.html#aa0d6ba401624b94fd16f2901bbcb708a", null ],
      [ "bp", "namespaceroutes_1_1payment__methods.html#a2315355543637459ab20b8073bc5b46b", null ]
    ] ]
];