var searchData=
[
  ['db_0',['db',['../namespacedb.html',1,'db'],['../namespacedb.html#aed82679f33f702c99769be3e2586c03b',1,'db.db']]],
  ['db_2epy_1',['db.py',['../db_8py.html',1,'']]],
  ['default_5flimit_2',['DEFAULT_LIMIT',['../classconfig_1_1_config.html#a9907409732c1c5dacf71634b2af5ce15',1,'config::Config']]],
  ['delete_5fcart_5fitem_3',['delete_cart_item',['../namespaceroutes_1_1cart.html#aa06a42cde515b508eb449a3222054bc4',1,'routes::cart']]],
  ['delete_5forder_4',['delete_order',['../namespaceroutes_1_1orders.html#a486a68249092b0daee16e948d4616cc9',1,'routes::orders']]],
  ['delete_5fpayment_5fmethod_5',['delete_payment_method',['../namespaceroutes_1_1payment__methods.html#a8e16b9d588d4f6a7a7ee8f7f11374bd5',1,'routes::payment_methods']]],
  ['description_6',['description',['../classmodels_1_1_category.html#a4a1f931f037bda5a355e0867158eaa9f',1,'models.Category.description'],['../classmodels_1_1_product.html#a9874987fccab2bf056f59505638f6d3e',1,'models.Product.description']]]
];
