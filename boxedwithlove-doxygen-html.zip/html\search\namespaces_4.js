var searchData=
[
  ['routes_0',['routes',['../namespaceroutes.html',1,'']]],
  ['routes_3a_3aauth_1',['auth',['../namespaceroutes_1_1auth.html',1,'routes']]],
  ['routes_3a_3acart_2',['cart',['../namespaceroutes_1_1cart.html',1,'routes']]],
  ['routes_3a_3acatalog_3',['catalog',['../namespaceroutes_1_1catalog.html',1,'routes']]],
  ['routes_3a_3aoptions_4',['options',['../namespaceroutes_1_1options.html',1,'routes']]],
  ['routes_3a_3aorders_5',['orders',['../namespaceroutes_1_1orders.html',1,'routes']]],
  ['routes_3a_3apayment_5fmethods_6',['payment_methods',['../namespaceroutes_1_1payment__methods.html',1,'routes']]]
];
