var searchData=
[
  ['unit_5fprice_5fcents_0',['unit_price_cents',['../classmodels_1_1_order_item.html#ad7601338e6e70372b6b6a4931c0a86b6',1,'models::OrderItem']]],
  ['user_1',['user',['../classmodels_1_1_cart_item.html#a4cf77211c1493a42000aa1b85b6857d2',1,'models.CartItem.user'],['../classmodels_1_1_review.html#a6709f892a959e4cfb747e8d24e9bbc68',1,'models.Review.user'],['../classmodels_1_1_payment_method.html#a84e9299583af9d873a95088750494df4',1,'models.PaymentMethod.user']]],
  ['user_5fid_2',['user_id',['../classmodels_1_1_address.html#af5041beb621e81efe579fd685d308d5e',1,'models.Address.user_id'],['../classmodels_1_1_cart_item.html#af920f04a54f6c2c46e6fdc11eb9aa7fb',1,'models.CartItem.user_id'],['../classmodels_1_1_order.html#aba76b25adb790eaba3449ed24a624ce2',1,'models.Order.user_id'],['../classmodels_1_1_review.html#a4f537b9449d781dda291759fce2deb4f',1,'models.Review.user_id'],['../classmodels_1_1_payment_method.html#a58bccdfce41535a3ff5393ca054915dd',1,'models.PaymentMethod.user_id']]]
];
