var searchData=
[
  ['create_5forder_0',['create_order',['../namespaceroutes_1_1orders.html#adf654edd7d8cecf8a10180c33ffe104a',1,'routes::orders']]],
  ['create_5fpayment_5fmethod_1',['create_payment_method',['../namespaceroutes_1_1payment__methods.html#ada95b63c06d686df5aa8376d29259f3f',1,'routes::payment_methods']]]
];
