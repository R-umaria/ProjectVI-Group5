var classmodels_1_1_order_item =
[
    [ "__tablename__", "classmodels_1_1_order_item.html#a51f3be33790a198ee53c2f8d44cc1810", null ],
    [ "id", "classmodels_1_1_order_item.html#a4b9ce09c4d5ade2d0da0792ed92b4cf6", null ],
    [ "order_id", "classmodels_1_1_order_item.html#af40afdad7e6b5fb0fe1e57217d61cc40", null ],
    [ "product", "classmodels_1_1_order_item.html#aaa29d72f72e6c1ce57078281720238b4", null ],
    [ "product_id", "classmodels_1_1_order_item.html#a3cf23c94ebc078052a7b39db26707ea1", null ],
    [ "quantity", "classmodels_1_1_order_item.html#a403aa6f02bcd89a0608949055bd06a95", null ],
    [ "unit_price_cents", "classmodels_1_1_order_item.html#ad7601338e6e70372b6b6a4931c0a86b6", null ]
];