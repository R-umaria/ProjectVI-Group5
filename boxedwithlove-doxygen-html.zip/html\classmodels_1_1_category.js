var classmodels_1_1_category =
[
    [ "__tablename__", "classmodels_1_1_category.html#aaba669ff02c5c8cf1c78cc0e32c5078b", null ],
    [ "category_name", "classmodels_1_1_category.html#a393353e3fd85deb3755ba7d3175ac6c9", null ],
    [ "description", "classmodels_1_1_category.html#a4a1f931f037bda5a355e0867158eaa9f", null ],
    [ "id", "classmodels_1_1_category.html#a4b1a15ea5ee9d4bd1c449b2727f4b3dc", null ],
    [ "products", "classmodels_1_1_category.html#a810ea09453ecfdd2eed6a17952c1fc45", null ]
];