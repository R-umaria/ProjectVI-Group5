var searchData=
[
  ['first_5fname_0',['first_name',['../classmodels_1_1_user.html#a4012d47a4e3b357c5999affa772b7663',1,'models::User']]]
];
