var searchData=
[
  ['quantity_0',['quantity',['../classmodels_1_1_cart_item.html#aa6aa183f4201a973c9d57a64af9ce401',1,'models.CartItem.quantity'],['../classmodels_1_1_order_item.html#a403aa6f02bcd89a0608949055bd06a95',1,'models.OrderItem.quantity']]]
];
