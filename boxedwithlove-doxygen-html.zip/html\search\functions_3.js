var searchData=
[
  ['delete_5fcart_5fitem_0',['delete_cart_item',['../namespaceroutes_1_1cart.html#aa06a42cde515b508eb449a3222054bc4',1,'routes::cart']]],
  ['delete_5forder_1',['delete_order',['../namespaceroutes_1_1orders.html#a486a68249092b0daee16e948d4616cc9',1,'routes::orders']]],
  ['delete_5fpayment_5fmethod_2',['delete_payment_method',['../namespaceroutes_1_1payment__methods.html#a8e16b9d588d4f6a7a7ee8f7f11374bd5',1,'routes::payment_methods']]]
];
