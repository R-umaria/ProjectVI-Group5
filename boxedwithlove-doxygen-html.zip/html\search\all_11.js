var searchData=
[
  ['tax_5frate_0',['TAX_RATE',['../namespaceroutes_1_1orders.html#a8a9e52b76fc29408f7819a2e82638b83',1,'routes::orders']]],
  ['to_5fdict_1',['to_dict',['../namespaceroutes_1_1payment__methods.html#a21cf32bc69aa8756cfd16548cd911833',1,'routes::payment_methods']]],
  ['total_5fcents_2',['total_cents',['../classmodels_1_1_order.html#a4aba87ed8d4536bb0e11e1862f9de238',1,'models::Order']]]
];
