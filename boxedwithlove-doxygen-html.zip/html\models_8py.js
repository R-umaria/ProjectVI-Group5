var models_8py =
[
    [ "models.User", "classmodels_1_1_user.html", "classmodels_1_1_user" ],
    [ "models.Address", "classmodels_1_1_address.html", "classmodels_1_1_address" ],
    [ "models.Category", "classmodels_1_1_category.html", "classmodels_1_1_category" ],
    [ "models.Product", "classmodels_1_1_product.html", "classmodels_1_1_product" ],
    [ "models.CartItem", "classmodels_1_1_cart_item.html", "classmodels_1_1_cart_item" ],
    [ "models.Order", "classmodels_1_1_order.html", "classmodels_1_1_order" ],
    [ "models.OrderItem", "classmodels_1_1_order_item.html", "classmodels_1_1_order_item" ],
    [ "models.Review", "classmodels_1_1_review.html", "classmodels_1_1_review" ],
    [ "models.PaymentMethod", "classmodels_1_1_payment_method.html", "classmodels_1_1_payment_method" ]
];