var db_8py =
[
    [ "db.db", "namespacedb.html#aed82679f33f702c99769be3e2586c03b", null ]
];