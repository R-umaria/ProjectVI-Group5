var classmodels_1_1_user =
[
    [ "__tablename__", "classmodels_1_1_user.html#aeaeaf5673e6fcacd3090eb9e170685a7", null ],
    [ "addresses", "classmodels_1_1_user.html#a890612e3342d517d829ff1be838d2a5b", null ],
    [ "created_at", "classmodels_1_1_user.html#a01a278f32c03edbba1668c721398653d", null ],
    [ "email", "classmodels_1_1_user.html#aaa88e21675421b6cebbef6eb5597046b", null ],
    [ "first_name", "classmodels_1_1_user.html#a4012d47a4e3b357c5999affa772b7663", null ],
    [ "id", "classmodels_1_1_user.html#a9a9aa1a53e9b8722a5f98595ceb52ae7", null ],
    [ "last_name", "classmodels_1_1_user.html#ad9ceaee4be821209d707dc4092c7528f", null ],
    [ "password_hash", "classmodels_1_1_user.html#ae530b1f91b657f97c5c2d88af181a0fc", null ],
    [ "phone_number", "classmodels_1_1_user.html#ae0b76eb582f0659194a994dcfac25de4", null ]
];