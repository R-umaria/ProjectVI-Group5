var classmodels_1_1_address =
[
    [ "__tablename__", "classmodels_1_1_address.html#a84515ed98d47f0a14b19f33e2812d3d3", null ],
    [ "country", "classmodels_1_1_address.html#ae0c5487c3a7b791d380b77ec5a400314", null ],
    [ "id", "classmodels_1_1_address.html#a8bd7707b7b12b7c580b4294e886667ec", null ],
    [ "label", "classmodels_1_1_address.html#a5db825c7d254768785164807c87ff7d4", null ],
    [ "postal_code", "classmodels_1_1_address.html#afce740477251c9bf82e8cb089a6da18c", null ],
    [ "street_address", "classmodels_1_1_address.html#a0fcf74071447d92d39299477f3626121", null ],
    [ "user_id", "classmodels_1_1_address.html#af5041beb621e81efe579fd685d308d5e", null ]
];