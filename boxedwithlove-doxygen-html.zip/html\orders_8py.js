var orders_8py =
[
    [ "routes.orders.create_order", "namespaceroutes_1_1orders.html#adf654edd7d8cecf8a10180c33ffe104a", null ],
    [ "routes.orders.delete_order", "namespaceroutes_1_1orders.html#a486a68249092b0daee16e948d4616cc9", null ],
    [ "routes.orders.ensure_payment_method", "namespaceroutes_1_1orders.html#a28857a0467b2ed333755763bd4c906e9", null ],
    [ "routes.orders.get_order", "namespaceroutes_1_1orders.html#af02bf1e87662e04caa321b833c0c912c", null ],
    [ "routes.orders.list_orders", "namespaceroutes_1_1orders.html#aa55e88c12b0d700d71c6b5f0b5d93cad", null ],
    [ "routes.orders.order_to_dict", "namespaceroutes_1_1orders.html#ab6579d3146331f02bb81fcd9b6f08a56", null ],
    [ "routes.orders.orders_options_collection", "namespaceroutes_1_1orders.html#ae453efa4018a45ff4697fa8fd9ea45cc", null ],
    [ "routes.orders.orders_options_item", "namespaceroutes_1_1orders.html#a0192a3bdcc717e86a52f5fa1da89bd6f", null ],
    [ "routes.orders.patch_order", "namespaceroutes_1_1orders.html#ac2dd20ff16ff4ff7a2869aed4b9176d0", null ],
    [ "routes.orders.require_user_id", "namespaceroutes_1_1orders.html#a28b4b9a0d2e698d1a6583a03aefd09da", null ],
    [ "routes.orders.bp", "namespaceroutes_1_1orders.html#a5460084f970cc7354c952867557be48d", null ],
    [ "routes.orders.TAX_RATE", "namespaceroutes_1_1orders.html#a8a9e52b76fc29408f7819a2e82638b83", null ]
];