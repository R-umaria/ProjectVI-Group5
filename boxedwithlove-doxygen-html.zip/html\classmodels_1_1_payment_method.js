var classmodels_1_1_payment_method =
[
    [ "__table_args__", "classmodels_1_1_payment_method.html#a0edfe20a3549d50f0fc474f2f40458a0", null ],
    [ "__tablename__", "classmodels_1_1_payment_method.html#ae5210503b086cdff1a516edf80f9a1af", null ],
    [ "billing_postal", "classmodels_1_1_payment_method.html#aa791e1024e41a6fd839c9b2bdb027d2f", null ],
    [ "brand", "classmodels_1_1_payment_method.html#a7fff31c9a766d3e3501ea72c4cf7a09f", null ],
    [ "cardholder_name", "classmodels_1_1_payment_method.html#a92829482dd846f61795b9db30e68d880", null ],
    [ "created_at", "classmodels_1_1_payment_method.html#adaa7e6fc87db7fc5762c0791013fe7e0", null ],
    [ "exp_month", "classmodels_1_1_payment_method.html#ac25e5377646519331f649e9567d4e2ad", null ],
    [ "exp_year", "classmodels_1_1_payment_method.html#a9fa2d6fd43152eb73f6adb5b2b6927ea", null ],
    [ "id", "classmodels_1_1_payment_method.html#ae36182709881b53bf1d74ef6d3c0b167", null ],
    [ "is_default", "classmodels_1_1_payment_method.html#a834725217bceb527cc44807e2c14444a", null ],
    [ "last4", "classmodels_1_1_payment_method.html#a3901f6ff4b989060c14ba0690d2fa7b5", null ],
    [ "user", "classmodels_1_1_payment_method.html#a84e9299583af9d873a95088750494df4", null ],
    [ "user_id", "classmodels_1_1_payment_method.html#a58bccdfce41535a3ff5393ca054915dd", null ]
];