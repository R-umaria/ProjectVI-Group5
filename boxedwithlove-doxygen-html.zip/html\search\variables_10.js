var searchData=
[
  ['tax_5frate_0',['TAX_RATE',['../namespaceroutes_1_1orders.html#a8a9e52b76fc29408f7819a2e82638b83',1,'routes::orders']]],
  ['total_5fcents_1',['total_cents',['../classmodels_1_1_order.html#a4aba87ed8d4536bb0e11e1862f9de238',1,'models::Order']]]
];
