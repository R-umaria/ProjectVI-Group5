var classmodels_1_1_review =
[
    [ "__tablename__", "classmodels_1_1_review.html#abd41ddbd88c3a60510cebe250ae096fa", null ],
    [ "comment", "classmodels_1_1_review.html#ae379206ba9c2f0448fa8426831ec4862", null ],
    [ "created_at", "classmodels_1_1_review.html#aa258cacf7f6ba9fe7aad615b63801d2e", null ],
    [ "id", "classmodels_1_1_review.html#a187d71ad5d4d620b4646744b2f61406e", null ],
    [ "product", "classmodels_1_1_review.html#a2b62de9a8220dd98e2ea7139fa9e425b", null ],
    [ "product_id", "classmodels_1_1_review.html#a5e0720d5ddb4efc8427b41e955082014", null ],
    [ "rating", "classmodels_1_1_review.html#a4a4c46b534d5f75c69eddd914d5c9665", null ],
    [ "user", "classmodels_1_1_review.html#a6709f892a959e4cfb747e8d24e9bbc68", null ],
    [ "user_id", "classmodels_1_1_review.html#a4f537b9449d781dda291759fce2deb4f", null ]
];