var files_dup =
[
    [ "routes", "dir_533417642d4c22e94ed6b0528ca3d24e.html", "dir_533417642d4c22e94ed6b0528ca3d24e" ],
    [ "app.py", "app_8py.html", null ],
    [ "config.py", "config_8py.html", "config_8py" ],
    [ "db.py", "db_8py.html", "db_8py" ],
    [ "models.py", "models_8py.html", "models_8py" ]
];