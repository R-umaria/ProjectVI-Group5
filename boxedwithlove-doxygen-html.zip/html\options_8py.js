var options_8py =
[
    [ "routes.options.options_route", "namespaceroutes_1_1options.html#a83109a171ef4f724f009da3b4aa05f2e", null ],
    [ "routes.options.bp", "namespaceroutes_1_1options.html#a1f0ec048e9fe9e4676f7b6ac090f9ad4", null ]
];