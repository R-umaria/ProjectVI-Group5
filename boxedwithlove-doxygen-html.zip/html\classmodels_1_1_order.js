var classmodels_1_1_order =
[
    [ "__tablename__", "classmodels_1_1_order.html#aa79fd7b309ddf28b0aac573e810e99cb", null ],
    [ "created_at", "classmodels_1_1_order.html#ad68cc0563bffecf3a8547339e98375c6", null ],
    [ "id", "classmodels_1_1_order.html#a1a540bd2dc3532fc4071ddfe58aa0cd5", null ],
    [ "items", "classmodels_1_1_order.html#af575c0dac2191338c10c5b1b8f2160e9", null ],
    [ "status", "classmodels_1_1_order.html#aaba40114a9e4739f6ac7ca7b393ae4f0", null ],
    [ "total_cents", "classmodels_1_1_order.html#a4aba87ed8d4536bb0e11e1862f9de238", null ],
    [ "user_id", "classmodels_1_1_order.html#aba76b25adb790eaba3449ed24a624ce2", null ]
];