var auth_8py =
[
    [ "routes.auth.get_me", "namespaceroutes_1_1auth.html#a941ceeac034b6fc791b1b65cd0b9c29c", null ],
    [ "routes.auth.get_password_errors", "namespaceroutes_1_1auth.html#ae72d63c7f169b0e6974046e7a6397bd5", null ],
    [ "routes.auth.login", "namespaceroutes_1_1auth.html#a5634e48b8913b959701258b269357eab", null ],
    [ "routes.auth.logout", "namespaceroutes_1_1auth.html#abcf624a86a19d8b2dcd3f6ddec10779d", null ],
    [ "routes.auth.register", "namespaceroutes_1_1auth.html#a4a26c96d5d787a01771914c46c28db00", null ],
    [ "routes.auth.bp", "namespaceroutes_1_1auth.html#ab593a571145431d044fca7c3625831ba", null ],
    [ "routes.auth.EMAIL_REGEX", "namespaceroutes_1_1auth.html#aeb88a12da324443158529d05ba1bff95", null ]
];