var searchData=
[
  ['partial_5fupdate_5fcart_5fitem_0',['partial_update_cart_item',['../namespaceroutes_1_1cart.html#a146b7142cd43cdb30bde204ae7e45db2',1,'routes::cart']]],
  ['patch_5forder_1',['patch_order',['../namespaceroutes_1_1orders.html#ac2dd20ff16ff4ff7a2869aed4b9176d0',1,'routes::orders']]],
  ['payment_5fmethods_5foptions_5fcollection_2',['payment_methods_options_collection',['../namespaceroutes_1_1payment__methods.html#a49d023f1094841c5fe62e0138e61f2c6',1,'routes::payment_methods']]],
  ['payment_5fmethods_5foptions_5fitem_3',['payment_methods_options_item',['../namespaceroutes_1_1payment__methods.html#a7f01c53b567ff4813b6c49097f6c2c64',1,'routes::payment_methods']]],
  ['product_5fdetail_4',['product_detail',['../namespaceroutes_1_1catalog.html#a59b3fa152eba208a533b4d1b13ec2fdc',1,'routes::catalog']]]
];
