var config_8py =
[
    [ "config.Config", "classconfig_1_1_config.html", "classconfig_1_1_config" ],
    [ "config._normalize_database_url", "namespaceconfig.html#ac9a14c68aead2bb58f12efb94199ea30", null ]
];