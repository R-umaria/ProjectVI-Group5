var searchData=
[
  ['db_0',['db',['../namespacedb.html#aed82679f33f702c99769be3e2586c03b',1,'db']]],
  ['default_5flimit_1',['DEFAULT_LIMIT',['../classconfig_1_1_config.html#a9907409732c1c5dacf71634b2af5ce15',1,'config::Config']]],
  ['description_2',['description',['../classmodels_1_1_category.html#a4a1f931f037bda5a355e0867158eaa9f',1,'models.Category.description'],['../classmodels_1_1_product.html#a9874987fccab2bf056f59505638f6d3e',1,'models.Product.description']]]
];
