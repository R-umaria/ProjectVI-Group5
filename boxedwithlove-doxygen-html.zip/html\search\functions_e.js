var searchData=
[
  ['update_5fcart_5fitem_0',['update_cart_item',['../namespaceroutes_1_1cart.html#a9eeac49273c3a0d3d7f04702d013a565',1,'routes::cart']]],
  ['update_5fpayment_5fmethod_1',['update_payment_method',['../namespaceroutes_1_1payment__methods.html#a74df6f97682f322527c309abe8ecc74e',1,'routes::payment_methods']]]
];
