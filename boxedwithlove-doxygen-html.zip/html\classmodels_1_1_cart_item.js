var classmodels_1_1_cart_item =
[
    [ "__table_args__", "classmodels_1_1_cart_item.html#ab8a6d360f414c17fd49eae5849e4a183", null ],
    [ "__tablename__", "classmodels_1_1_cart_item.html#ae505ad91cd7c0ed01acfed8c8e752d27", null ],
    [ "id", "classmodels_1_1_cart_item.html#a2b87709f4715dbc46c464a39e4f7f16e", null ],
    [ "product", "classmodels_1_1_cart_item.html#af78855faf30b82deb8ec20b369bd38a8", null ],
    [ "product_id", "classmodels_1_1_cart_item.html#a4f3948db4c4b2bb3a8a5d800a25235ce", null ],
    [ "quantity", "classmodels_1_1_cart_item.html#aa6aa183f4201a973c9d57a64af9ce401", null ],
    [ "user", "classmodels_1_1_cart_item.html#a4cf77211c1493a42000aa1b85b6857d2", null ],
    [ "user_id", "classmodels_1_1_cart_item.html#af920f04a54f6c2c46e6fdc11eb9aa7fb", null ]
];