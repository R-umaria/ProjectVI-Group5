var searchData=
[
  ['rating_0',['rating',['../classmodels_1_1_review.html#a4a4c46b534d5f75c69eddd914d5c9665',1,'models::Review']]],
  ['reviews_1',['reviews',['../classmodels_1_1_product.html#a7cd9aa7a5b6c18d8f21296e92939245d',1,'models::Product']]]
];
