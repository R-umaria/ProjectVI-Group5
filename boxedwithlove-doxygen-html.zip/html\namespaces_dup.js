var namespaces_dup =
[
    [ "app", "namespaceapp.html", null ],
    [ "config", "namespaceconfig.html", "namespaceconfig" ],
    [ "db", "namespacedb.html", [
      [ "db", "namespacedb.html#aed82679f33f702c99769be3e2586c03b", null ]
    ] ],
    [ "models", "namespacemodels.html", "namespacemodels" ],
    [ "routes", "namespaceroutes.html", "namespaceroutes" ]
];