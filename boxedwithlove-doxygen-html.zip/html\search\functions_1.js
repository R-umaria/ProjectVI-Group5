var searchData=
[
  ['add_5freview_0',['add_review',['../namespaceroutes_1_1catalog.html#acdfe3ca0508fa479d2ff533630d67000',1,'routes::catalog']]],
  ['add_5fto_5fcart_1',['add_to_cart',['../namespaceroutes_1_1cart.html#a8c7727a491f55e8f2a56f1b917c111b6',1,'routes::cart']]],
  ['apply_5fdefault_5frule_2',['apply_default_rule',['../namespaceroutes_1_1payment__methods.html#ac7148d4eb400cf50105277c4cd4ce8fb',1,'routes::payment_methods']]]
];
